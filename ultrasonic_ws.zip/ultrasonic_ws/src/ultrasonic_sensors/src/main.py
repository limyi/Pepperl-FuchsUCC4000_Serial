#!/usr/bin/env python3

import rospy
from std_msgs.msg import Int32MultiArray
from geometry_msgs.msg import Twist
import serial
import serial.tools.list_ports
from serial.tools import list_ports
import struct
import time
import sys
import distance_lib as distance_lib

class RosHandler:

    def __init__(self):

        self.data_publisher = rospy.Publisher("/ultrasonic_data", Twist, queue_size=3)
        #Command to read address Address1:"A9FCFE73", Address2:"AAFCFE43", Address3:"ABFCFE52", Address4:"ACFCFE70", Address5:"ADFCFE61", Address6:"AEFCFE51", Address7:"AFFCFE40"
        self.address1 = "A9FCFE73"
        self.address2 = "AAFCFE43"
        self.address3 = "ABFCFE52"
        self.address4 = "ACFCFE70"
        self.address5 = "ADFCFE61"
        self.address6 = "AEFCFE51"
        self.address7 = "AFFCFE40"
	#"AI06B90T" "A505HS9H""AQ00F1QY"   "A505HS1X"   				#Examples of USB Serial Number. Linux Command: usb-devices to get USB Information and Serial Number
        #p = list(serial.tools.list_ports.grep("AI06B90T"))
        #port = '/dev/' + p[0].name            						#FIND PORT Based on USB Serial Number
        #print("PORT",port)
        self.Panthera_ultrasonic   = distance_lib.dis('/dev/ttyUSB0',self.address2)
        self.Panthera_ultrasonic_1 = distance_lib.dis('/dev/ttyUSB1',self.address3)
        self.Panthera_ultrasonic_2 = distance_lib.dis('/dev/ttyUSB2',self.address3)
        self.Panthera_ultrasonic_3 = distance_lib.dis('/dev/ttyUSB3',self.address1)
        self.Panthera_ultrasonic_4 = distance_lib.dis('/dev/ttyUSB4',self.address5)

    def run(self):

        while not rospy.is_shutdown():
           
            distance   = self.Panthera_ultrasonic.readDistanceInfo()
            distance_1 = self.Panthera_ultrasonic_1.readDistanceInfo()
            distance_2 = self.Panthera_ultrasonic_2.readDistanceInfo()
            distance_3 = self.Panthera_ultrasonic_3.readDistanceInfo()  
            distance_4 = self.Panthera_ultrasonic_4.readDistanceInfo()
       
            data_array = Twist()

            data_array.linear.x  = distance
            data_array.linear.y  = distance_1
            data_array.linear.z  = distance_2
            data_array.angular.x = distance_3
            data_array.angular.y = distance_4
            data_array.angular.z = 0

		
	

            self.data_publisher.publish(data_array)
            rospy.sleep(0.1)
        return 

if __name__ == '__main__':
    rospy.init_node('ultrasonic_node')
    rate = rospy.Rate(10) # 10hz
    rh = RosHandler()
    rh.run()
